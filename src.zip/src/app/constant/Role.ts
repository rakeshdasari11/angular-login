export enum Role{
UserSupervisor = 'User',
Admin = 'Admin'
}

